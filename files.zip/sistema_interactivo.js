// sistema_interactivo.js
// M3S1 - Sistema interactivo de mensajes

// Función principal que se ejecuta al presionar el botón
function iniciarSistema() {

  // TASK 2: Solicitar nombre al usuario
  const nombreUsuario = prompt("¿Cuál es tu nombre?");

  // TASK 2: Solicitar edad al usuario
  const edadIngresada = prompt("¿Cuántos años tienes?");

  // Convertir la edad a número
  const edadUsuario = Number(edadIngresada);

  // TASK 3: Validar que la edad sea un número válido
  if (isNaN(edadUsuario) || edadIngresada === null || edadIngresada.trim() === "") {
    console.error("Error: Por favor, ingresa una edad válida en números.");
    alert("❌ Error: Por favor, ingresa una edad válida en números.");
    return;
  }

  // TASK 4: Mostrar mensaje según la edad
  if (edadUsuario < 18) {
    // Mensaje para menores de edad
    alert("Hola " + nombreUsuario + ", eres menor de edad. ¡Sigue aprendiendo y disfrutando del código!");
  } else {
    // Mensaje para mayores de edad
    alert("Hola " + nombreUsuario + ", eres mayor de edad. ¡Prepárate para grandes oportunidades en el mundo de la programación!");
  }
}

// Ejecutar automáticamente al cargar la página
iniciarSistema();
